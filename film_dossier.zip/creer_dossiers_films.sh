#!/bin/sh

# Répertoire de destination pour les dossiers de films
DESTINATION="/mnt/DATA/medias/Films"

# Fichier contenant la liste des films
LISTE="films.txt"

# Lire chaque ligne (en sautant l'en-tête de la première colonne) et créer un dossier
tail -n +2 "$LISTE" | while IFS= read -r film || [ -n "$film" ]; do
  # Sauter les lignes vides
  [ -z "$film" ] && continue

  # Nettoyer le nom du dossier pour enlever les caractères interdits
  dossier=$(echo "$film" | sed 's/[\/:\*?"<>|]/_/g')

  # Créer le dossier
  mkdir -p "$DESTINATION/$dossier"
  echo "📁 Dossier créé : $DESTINATION/$dossier"
done
